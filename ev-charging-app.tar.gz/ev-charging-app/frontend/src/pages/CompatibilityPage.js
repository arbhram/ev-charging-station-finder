import React, { useState, useEffect } from 'react';
import vehicleService from '../services/vehicleService';
import StationCard from '../components/Station/StationCard';
import MapView from '../components/Map/MapView';
import { LoadingSpinner, ErrorMessage } from '../components/Common/SharedComponents';
import { useGeolocation } from '../hooks/useCustomHooks';

/**
 * Charger Compatibility Page
 * Select a vehicle to see compatible charging stations.
 */
const CompatibilityPage = () => {
  const { location: userLocation } = useGeolocation();
  const [vehicles, setVehicles] = useState([]);
  const [selectedVehicle, setSelectedVehicle] = useState(null);
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [vehiclesLoading, setVehiclesLoading] = useState(true);
  const [error, setError] = useState(null);

  // Fetch vehicles on mount
  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        const response = await vehicleService.getAll();
        setVehicles(response.data || []);
      } catch (err) {
        setError('Failed to load vehicles');
      } finally {
        setVehiclesLoading(false);
      }
    };
    fetchVehicles();
  }, []);

  // Fetch compatible stations when vehicle is selected
  useEffect(() => {
    if (!selectedVehicle || !userLocation) return;

    const fetchCompatible = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await vehicleService.getCompatibleStations(
          selectedVehicle._id,
          userLocation.lat,
          userLocation.lng,
          100
        );
        setStations(response.data?.stations || []);
      } catch (err) {
        setError('Failed to load compatible stations');
      } finally {
        setLoading(false);
      }
    };
    fetchCompatible();
  }, [selectedVehicle, userLocation]);

  // Group vehicles by make
  const vehiclesByMake = vehicles.reduce((acc, vehicle) => {
    if (!acc[vehicle.make]) acc[vehicle.make] = [];
    acc[vehicle.make].push(vehicle);
    return acc;
  }, {});

  return (
    <div className="min-h-screen pt-16 bg-carbon-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="section-title flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 16.875h3.375m0 0h3.375m-3.375 0V13.5m0 3.375v3.375M6 10.5h2.25a2.25 2.25 0 002.25-2.25V6a2.25 2.25 0 00-2.25-2.25H6A2.25 2.25 0 003.75 6v2.25A2.25 2.25 0 006 10.5zm0 9.75h2.25A2.25 2.25 0 0010.5 18v-2.25a2.25 2.25 0 00-2.25-2.25H6a2.25 2.25 0 00-2.25 2.25V18A2.25 2.25 0 006 20.25zm9.75-9.75H18a2.25 2.25 0 002.25-2.25V6A2.25 2.25 0 0018 3.75h-2.25A2.25 2.25 0 0013.5 6v2.25a2.25 2.25 0 002.25 2.25z" />
              </svg>
            </span>
            Charger Compatibility
          </h1>
          <p className="section-subtitle mt-1">Find compatible charging stations for your electric vehicle</p>
        </div>

        {/* Vehicle Selection */}
        <div className="card mb-6">
          <h3 className="text-sm font-semibold text-carbon-300 mb-4">Select Your Vehicle</h3>
          {vehiclesLoading ? (
            <LoadingSpinner message="Loading vehicles..." />
          ) : (
            <div className="space-y-4">
              {Object.entries(vehiclesByMake).map(([make, models]) => (
                <div key={make}>
                  <h4 className="text-xs font-semibold text-carbon-500 uppercase tracking-wider mb-2">{make}</h4>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2">
                    {models.map((vehicle) => (
                      <button
                        key={vehicle._id}
                        onClick={() => setSelectedVehicle(vehicle)}
                        className={`text-left p-3 rounded-xl transition-all ${
                          selectedVehicle?._id === vehicle._id
                            ? 'bg-primary-600/10 border-primary-500/30 text-primary-400 border'
                            : 'bg-carbon-800/50 border border-transparent text-carbon-300 hover:bg-carbon-800 hover:text-white'
                        }`}
                      >
                        <p className="text-sm font-medium">{vehicle.model}</p>
                        <p className="text-[11px] text-carbon-500 mt-0.5">
                          {vehicle.batteryCapacity} kWh · {vehicle.range} km
                        </p>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected vehicle info */}
        {selectedVehicle && (
          <div className="card mb-6 animate-slide-up">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-semibold text-white">
                  {selectedVehicle.make} {selectedVehicle.model} ({selectedVehicle.year})
                </h3>
                <p className="text-sm text-carbon-500 mt-1">
                  {selectedVehicle.batteryCapacity} kWh · {selectedVehicle.range} km range
                </p>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {selectedVehicle.compatibleConnectors?.map((connector, idx) => (
                  <span key={idx} className="badge-green">{connector}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {error && <ErrorMessage message={error} />}

        {/* Results */}
        {selectedVehicle && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Station list */}
            <div>
              <h3 className="text-sm font-semibold text-carbon-300 mb-3">
                Compatible Stations {stations.length > 0 && `(${stations.length})`}
              </h3>
              {loading ? (
                <LoadingSpinner message="Finding compatible stations..." />
              ) : stations.length > 0 ? (
                <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                  {stations.map((station) => (
                    <StationCard key={station._id} station={station} compact />
                  ))}
                </div>
              ) : (
                <div className="card text-center py-12">
                  <p className="text-carbon-500 text-sm">No compatible stations found nearby</p>
                  <p className="text-carbon-600 text-xs mt-1">Try expanding your search area</p>
                </div>
              )}
            </div>

            {/* Map */}
            <div>
              <MapView
                center={userLocation ? [userLocation.lat, userLocation.lng] : [-33.8688, 151.2093]}
                zoom={10}
                stations={stations}
                userLocation={userLocation}
                className="h-[500px] lg:h-[600px]"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CompatibilityPage;
