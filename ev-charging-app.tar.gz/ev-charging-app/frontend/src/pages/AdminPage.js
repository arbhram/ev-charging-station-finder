import React, { useState, useEffect } from 'react';
import stationService from '../services/stationService';
import { LoadingSpinner, ErrorMessage } from '../components/Common/SharedComponents';
import { formatCurrency } from '../utils/helpers';

/**
 * Admin Dashboard
 * Manage stations, view analytics, and administer the platform.
 */
const AdminPage = () => {
  const [analytics, setAnalytics] = useState(null);
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddForm, setShowAddForm] = useState(false);
  const [newStation, setNewStation] = useState({
    name: '',
    latitude: '',
    longitude: '',
    chargerLevel: 'Level 2',
    formattedAddress: '',
    connectorType: 'Type 2',
    connectorPower: 22,
    pricePerKWh: 0.40,
  });

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [analyticsRes, stationsRes] = await Promise.all([
        stationService.getAnalytics(),
        stationService.getAll({ limit: 50 }),
      ]);
      setAnalytics(analyticsRes.data);
      setStations(stationsRes.data || []);
    } catch (err) {
      setError('Failed to load admin data');
    } finally {
      setLoading(false);
    }
  };

  const handleAddStation = async (e) => {
    e.preventDefault();
    try {
      await stationService.create({
        name: newStation.name,
        location: {
          type: 'Point',
          coordinates: [Number(newStation.longitude), Number(newStation.latitude)],
          formattedAddress: newStation.formattedAddress,
        },
        chargerLevel: newStation.chargerLevel,
        connectors: [{
          type: newStation.connectorType,
          powerKW: Number(newStation.connectorPower),
          quantity: 1,
          available: 1,
          status: 'available',
        }],
        pricing: {
          perKWh: Number(newStation.pricePerKWh),
          currency: 'AUD',
          isFree: Number(newStation.pricePerKWh) === 0,
        },
      });
      setShowAddForm(false);
      fetchData();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to create station');
    }
  };

  const handleDeleteStation = async (id) => {
    if (!window.confirm('Are you sure you want to delete this station?')) return;
    try {
      await stationService.delete(id);
      setStations((prev) => prev.filter((s) => s._id !== id));
    } catch (err) {
      setError('Failed to delete station');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen pt-16 flex items-center justify-center">
        <LoadingSpinner size="lg" message="Loading admin panel..." />
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-16 bg-carbon-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="section-title">Admin Dashboard</h1>
            <p className="section-subtitle mt-1">Manage stations and view platform analytics</p>
          </div>
          <button onClick={() => setShowAddForm(!showAddForm)} className="btn-primary">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
            </svg>
            Add Station
          </button>
        </div>

        {error && <div className="mb-4"><ErrorMessage message={error} /></div>}

        {/* Add Station Form */}
        {showAddForm && (
          <div className="card mb-6 animate-slide-up">
            <h3 className="text-base font-semibold text-white mb-4">Add New Station</h3>
            <form onSubmit={handleAddStation} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <div>
                <label className="label-text">Station Name</label>
                <input value={newStation.name} onChange={(e) => setNewStation({ ...newStation, name: e.target.value })} className="input-field text-sm" required />
              </div>
              <div>
                <label className="label-text">Latitude</label>
                <input type="number" step="any" value={newStation.latitude} onChange={(e) => setNewStation({ ...newStation, latitude: e.target.value })} className="input-field text-sm" required />
              </div>
              <div>
                <label className="label-text">Longitude</label>
                <input type="number" step="any" value={newStation.longitude} onChange={(e) => setNewStation({ ...newStation, longitude: e.target.value })} className="input-field text-sm" required />
              </div>
              <div>
                <label className="label-text">Address</label>
                <input value={newStation.formattedAddress} onChange={(e) => setNewStation({ ...newStation, formattedAddress: e.target.value })} className="input-field text-sm" />
              </div>
              <div>
                <label className="label-text">Charger Level</label>
                <select value={newStation.chargerLevel} onChange={(e) => setNewStation({ ...newStation, chargerLevel: e.target.value })} className="input-field text-sm">
                  <option value="Level 1">Level 1</option>
                  <option value="Level 2">Level 2</option>
                  <option value="DC Fast Charger">DC Fast Charger</option>
                </select>
              </div>
              <div>
                <label className="label-text">Connector Type</label>
                <select value={newStation.connectorType} onChange={(e) => setNewStation({ ...newStation, connectorType: e.target.value })} className="input-field text-sm">
                  <option value="Type 2">Type 2</option>
                  <option value="CCS2">CCS2</option>
                  <option value="CHAdeMO">CHAdeMO</option>
                  <option value="Tesla Supercharger">Tesla Supercharger</option>
                </select>
              </div>
              <div>
                <label className="label-text">Power (kW)</label>
                <input type="number" value={newStation.connectorPower} onChange={(e) => setNewStation({ ...newStation, connectorPower: e.target.value })} className="input-field text-sm" />
              </div>
              <div>
                <label className="label-text">Price per kWh ($)</label>
                <input type="number" step="0.01" value={newStation.pricePerKWh} onChange={(e) => setNewStation({ ...newStation, pricePerKWh: e.target.value })} className="input-field text-sm" />
              </div>
              <div className="flex items-end gap-2">
                <button type="submit" className="btn-primary">Create</button>
                <button type="button" onClick={() => setShowAddForm(false)} className="btn-secondary">Cancel</button>
              </div>
            </form>
          </div>
        )}

        {/* Analytics cards */}
        {analytics && (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <div className="card text-center">
              <p className="text-3xl font-bold text-white">{analytics.totalStations}</p>
              <p className="text-xs text-carbon-500 mt-1">Total Stations</p>
            </div>
            {analytics.stationsByLevel?.map((level, idx) => (
              <div key={idx} className="card text-center">
                <p className="text-3xl font-bold text-primary-400">{level.count}</p>
                <p className="text-xs text-carbon-500 mt-1">{level._id}</p>
              </div>
            ))}
          </div>
        )}

        {/* Connector type breakdown */}
        {analytics?.stationsByConnector && (
          <div className="card mb-6">
            <h3 className="text-sm font-semibold text-carbon-300 mb-3">Connector Distribution</h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {analytics.stationsByConnector.map((ct, idx) => (
                <div key={idx} className="bg-carbon-800/50 rounded-xl p-3 text-center">
                  <p className="text-lg font-bold text-white">{ct.count}</p>
                  <p className="text-xs text-carbon-500">{ct._id}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Station management table */}
        <div className="card overflow-hidden">
          <h3 className="text-sm font-semibold text-carbon-300 mb-4">
            All Stations ({stations.length})
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-carbon-800">
                  <th className="text-left py-3 px-3 text-carbon-500 font-medium">Station</th>
                  <th className="text-left py-3 px-3 text-carbon-500 font-medium">Level</th>
                  <th className="text-left py-3 px-3 text-carbon-500 font-medium">Connectors</th>
                  <th className="text-left py-3 px-3 text-carbon-500 font-medium">Price</th>
                  <th className="text-right py-3 px-3 text-carbon-500 font-medium">Actions</th>
                </tr>
              </thead>
              <tbody>
                {stations.map((station) => (
                  <tr key={station._id} className="border-b border-carbon-800/50 hover:bg-carbon-800/20 transition-colors">
                    <td className="py-3 px-3">
                      <p className="text-white font-medium truncate max-w-[200px]">{station.name}</p>
                      <p className="text-[11px] text-carbon-600 truncate max-w-[200px]">
                        {station.location?.address?.city || ''}
                      </p>
                    </td>
                    <td className="py-3 px-3 text-carbon-300">{station.chargerLevel}</td>
                    <td className="py-3 px-3">
                      <div className="flex flex-wrap gap-1">
                        {station.connectors?.slice(0, 2).map((c, i) => (
                          <span key={i} className="text-[10px] px-1.5 py-0.5 bg-carbon-800 rounded text-carbon-400">
                            {c.type}
                          </span>
                        ))}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-carbon-300">
                      {station.pricing?.isFree ? 'Free' : formatCurrency(station.pricing?.perKWh || 0)}
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => handleDeleteStation(station._id)}
                        className="text-red-500/60 hover:text-red-400 transition-colors p-1"
                        title="Delete station"
                      >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.164-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.037-2.09 1.022-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0" />
                        </svg>
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
