import React, { useState } from 'react';
import MapView from '../components/Map/MapView';
import { LoadingSpinner, ErrorMessage } from '../components/Common/SharedComponents';
import routeService from '../services/routeService';
import { formatCurrency } from '../utils/helpers';

/**
 * Route Planner Page
 * Plan a route with charging stops based on vehicle range.
 */
const RoutePlannerPage = () => {
  const [origin, setOrigin] = useState({ name: '', lat: '', lng: '' });
  const [destination, setDestination] = useState({ name: '', lat: '', lng: '' });
  const [vehicleRange, setVehicleRange] = useState(400);
  const [currentBattery, setCurrentBattery] = useState(80);
  const [batteryCapacity, setBatteryCapacity] = useState(60);
  const [routeResult, setRouteResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Preset routes for quick selection
  const presetRoutes = [
    { label: 'Sydney → Melbourne', origin: { name: 'Sydney', lat: -33.8688, lng: 151.2093 }, destination: { name: 'Melbourne', lat: -37.8136, lng: 144.9631 } },
    { label: 'Sydney → Canberra', origin: { name: 'Sydney', lat: -33.8688, lng: 151.2093 }, destination: { name: 'Canberra', lat: -35.2809, lng: 149.1300 } },
    { label: 'Melbourne → Adelaide', origin: { name: 'Melbourne', lat: -37.8136, lng: 144.9631 }, destination: { name: 'Adelaide', lat: -34.9285, lng: 138.6007 } },
    { label: 'Sydney → Brisbane', origin: { name: 'Sydney', lat: -33.8688, lng: 151.2093 }, destination: { name: 'Brisbane', lat: -27.4698, lng: 153.0251 } },
  ];

  const handlePresetSelect = (preset) => {
    setOrigin(preset.origin);
    setDestination(preset.destination);
  };

  const handlePlanRoute = async (e) => {
    e.preventDefault();
    if (!origin.lat || !destination.lat) {
      setError('Please enter valid origin and destination coordinates');
      return;
    }

    setLoading(true);
    setError(null);
    setRouteResult(null);

    try {
      const response = await routeService.planRoute({
        origin: { name: origin.name, lat: Number(origin.lat), lng: Number(origin.lng) },
        destination: { name: destination.name, lat: Number(destination.lat), lng: Number(destination.lng) },
        vehicleRange: Number(vehicleRange),
        currentBattery: Number(currentBattery),
        batteryCapacity: Number(batteryCapacity),
      });
      setRouteResult(response.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to plan route');
    } finally {
      setLoading(false);
    }
  };

  // Build map markers from route result
  const getRouteStations = () => {
    if (!routeResult?.chargingStops) return [];
    return routeResult.chargingStops.map((stop) => ({
      _id: stop.station.id,
      name: stop.station.name,
      location: { coordinates: stop.station.coordinates },
      chargerLevel: stop.station.chargerLevel,
      connectors: stop.station.connectors,
      pricing: {},
    }));
  };

  // Build route line coordinates
  const getRouteCoordinates = () => {
    if (!routeResult) return null;
    const points = [];
    if (routeResult.origin?.coordinates) {
      points.push([routeResult.origin.coordinates[1], routeResult.origin.coordinates[0]]);
    }
    routeResult.chargingStops?.forEach((stop) => {
      if (stop.station.coordinates) {
        points.push([stop.station.coordinates[1], stop.station.coordinates[0]]);
      }
    });
    if (routeResult.destination?.coordinates) {
      points.push([routeResult.destination.coordinates[1], routeResult.destination.coordinates[0]]);
    }
    return points.length > 1 ? points : null;
  };

  const mapCenter = routeResult?.origin?.coordinates
    ? [routeResult.origin.coordinates[1], routeResult.origin.coordinates[0]]
    : [-33.8688, 151.2093];

  return (
    <div className="min-h-screen pt-16 bg-carbon-950">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="section-title flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-primary-600/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 6.75V15m6-6v8.25m.503 3.498l4.875-2.437c.381-.19.622-.58.622-1.006V4.82c0-.836-.88-1.38-1.628-1.006l-3.869 1.934c-.317.159-.69.159-1.006 0L9.503 3.252a1.125 1.125 0 00-1.006 0L3.622 5.689C3.24 5.88 3 6.27 3 6.695V19.18c0 .836.88 1.38 1.628 1.006l3.869-1.934c.317-.159.69-.159 1.006 0l4.994 2.497c.317.158.69.158 1.006 0z" />
              </svg>
            </span>
            Route Planner
          </h1>
          <p className="section-subtitle mt-1">Plan your trip with optimal charging stops along the way</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Form */}
          <div className="lg:col-span-1 space-y-6">
            {/* Quick presets */}
            <div className="card">
              <h3 className="text-sm font-semibold text-carbon-300 mb-3">Popular Routes</h3>
              <div className="grid grid-cols-1 gap-2">
                {presetRoutes.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handlePresetSelect(preset)}
                    className="text-left px-3 py-2.5 rounded-xl text-sm bg-carbon-800/50 hover:bg-carbon-800 text-carbon-300 hover:text-white transition-colors"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Route form */}
            <form onSubmit={handlePlanRoute} className="card space-y-4">
              <h3 className="text-sm font-semibold text-carbon-300">Route Details</h3>

              <div>
                <label className="label-text">Origin</label>
                <input
                  type="text"
                  value={origin.name}
                  onChange={(e) => setOrigin({ ...origin, name: e.target.value })}
                  placeholder="City name"
                  className="input-field text-sm"
                />
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <input type="number" step="any" value={origin.lat} onChange={(e) => setOrigin({ ...origin, lat: e.target.value })} placeholder="Latitude" className="input-field text-xs !py-2" />
                  <input type="number" step="any" value={origin.lng} onChange={(e) => setOrigin({ ...origin, lng: e.target.value })} placeholder="Longitude" className="input-field text-xs !py-2" />
                </div>
              </div>

              <div>
                <label className="label-text">Destination</label>
                <input
                  type="text"
                  value={destination.name}
                  onChange={(e) => setDestination({ ...destination, name: e.target.value })}
                  placeholder="City name"
                  className="input-field text-sm"
                />
                <div className="grid grid-cols-2 gap-2 mt-2">
                  <input type="number" step="any" value={destination.lat} onChange={(e) => setDestination({ ...destination, lat: e.target.value })} placeholder="Latitude" className="input-field text-xs !py-2" />
                  <input type="number" step="any" value={destination.lng} onChange={(e) => setDestination({ ...destination, lng: e.target.value })} placeholder="Longitude" className="input-field text-xs !py-2" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="label-text">Vehicle Range (km)</label>
                  <input type="number" value={vehicleRange} onChange={(e) => setVehicleRange(e.target.value)} className="input-field text-sm" />
                </div>
                <div>
                  <label className="label-text">Battery (kWh)</label>
                  <input type="number" value={batteryCapacity} onChange={(e) => setBatteryCapacity(e.target.value)} className="input-field text-sm" />
                </div>
              </div>

              <div>
                <label className="label-text">Current Battery: {currentBattery}%</label>
                <input
                  type="range"
                  min="5"
                  max="100"
                  value={currentBattery}
                  onChange={(e) => setCurrentBattery(Number(e.target.value))}
                  className="w-full accent-primary-500"
                />
                <div className="flex justify-between text-[10px] text-carbon-600 mt-1">
                  <span>5%</span><span>100%</span>
                </div>
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? 'Planning...' : 'Plan Route'}
              </button>
            </form>

            {error && <ErrorMessage message={error} />}

            {/* Route result summary */}
            {routeResult && (
              <div className="card space-y-4 animate-slide-up">
                <h3 className="text-sm font-semibold text-white">Route Summary</h3>
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-carbon-800/50 rounded-xl p-3">
                    <p className="text-xs text-carbon-500">Total Distance</p>
                    <p className="text-lg font-bold text-white">{routeResult.totalDistance} km</p>
                  </div>
                  <div className="bg-carbon-800/50 rounded-xl p-3">
                    <p className="text-xs text-carbon-500">Drive Time</p>
                    <p className="text-lg font-bold text-white">{routeResult.estimatedDrivingTime}</p>
                  </div>
                  <div className="bg-carbon-800/50 rounded-xl p-3">
                    <p className="text-xs text-carbon-500">Charging Time</p>
                    <p className="text-lg font-bold text-primary-400">{routeResult.totalChargingTime}</p>
                  </div>
                  <div className="bg-carbon-800/50 rounded-xl p-3">
                    <p className="text-xs text-carbon-500">Charging Cost</p>
                    <p className="text-lg font-bold text-volt-400">{formatCurrency(routeResult.totalChargingCost)}</p>
                  </div>
                </div>

                <div>
                  <h4 className="text-xs font-semibold text-carbon-400 mb-2">
                    Charging Stops ({routeResult.stopsRequired})
                  </h4>
                  <div className="space-y-2">
                    {routeResult.chargingStops?.map((stop, idx) => (
                      <div key={idx} className="flex items-start gap-3 bg-carbon-800/30 rounded-xl p-3">
                        <div className="w-6 h-6 rounded-lg bg-primary-600/20 flex items-center justify-center text-primary-400 text-xs font-bold flex-shrink-0 mt-0.5">
                          {stop.order}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-white truncate">{stop.station.name}</p>
                          <div className="flex items-center gap-2 mt-1 text-xs text-carbon-500">
                            <span>{stop.station.chargerLevel}</span>
                            <span>·</span>
                            <span>{stop.estimatedChargingTime}</span>
                            <span>·</span>
                            <span>{formatCurrency(stop.estimatedCost)}</span>
                          </div>
                          <div className="flex items-center gap-3 mt-1.5">
                            <span className="text-[11px] text-volt-400">Arrive: {stop.estimatedArrivalBattery}%</span>
                            <span className="text-[11px] text-primary-400">Depart: {stop.estimatedDepartureBattery}%</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Map */}
          <div className="lg:col-span-2">
            <MapView
              center={mapCenter}
              zoom={routeResult ? 6 : 10}
              stations={getRouteStations()}
              routeCoordinates={getRouteCoordinates()}
              className="h-[600px] lg:h-[calc(100vh-180px)] sticky top-24"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default RoutePlannerPage;
