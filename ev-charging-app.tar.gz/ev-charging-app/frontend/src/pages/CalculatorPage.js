import React, { useState } from 'react';
import calculatorService from '../services/calculatorService';
import { formatCurrency } from '../utils/helpers';
import { ErrorMessage } from '../components/Common/SharedComponents';

/**
 * Charging Calculator Page
 * Calculates charging time, cost, and energy based on user inputs.
 */
const CalculatorPage = () => {
  const [formData, setFormData] = useState({
    batteryCapacity: 60,
    currentPercent: 20,
    targetPercent: 80,
    chargerLevel: 'DC Fast Charger',
    pricePerKWh: 0.45,
  });
  const [result, setResult] = useState(null);
  const [quickResult, setQuickResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleCalculate = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const [calcResponse, quickResponse] = await Promise.all([
        calculatorService.calculate({
          batteryCapacity: Number(formData.batteryCapacity),
          currentPercent: Number(formData.currentPercent),
          targetPercent: Number(formData.targetPercent),
          chargerLevel: formData.chargerLevel,
          pricing: {
            perKWh: Number(formData.pricePerKWh),
            currency: 'AUD',
            isFree: false,
          },
        }),
        calculatorService.quickEstimate({
          batteryCapacity: Number(formData.batteryCapacity),
          currentPercent: Number(formData.currentPercent),
          targetPercent: Number(formData.targetPercent),
        }),
      ]);
      setResult(calcResponse.data);
      setQuickResult(quickResponse.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Calculation failed');
    } finally {
      setLoading(false);
    }
  };

  // Common EV presets
  const presets = [
    { label: 'Tesla Model 3', battery: 60, range: 491 },
    { label: 'Tesla Model Y', battery: 75, range: 533 },
    { label: 'Nissan Leaf', battery: 40, range: 270 },
    { label: 'BYD Atto 3', battery: 60.48, range: 420 },
    { label: 'Hyundai Ioniq 5', battery: 77.4, range: 507 },
    { label: 'Kia EV6', battery: 77.4, range: 528 },
  ];

  return (
    <div className="min-h-screen pt-16 bg-carbon-950">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="section-title flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-volt-500/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-volt-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
              </svg>
            </span>
            Charging Calculator
          </h1>
          <p className="section-subtitle mt-1">Estimate charging time, cost, and energy for your EV</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input form */}
          <div className="space-y-6">
            {/* Vehicle presets */}
            <div className="card">
              <h3 className="text-sm font-semibold text-carbon-300 mb-3">Quick Select Vehicle</h3>
              <div className="grid grid-cols-2 gap-2">
                {presets.map((preset, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleChange('batteryCapacity', preset.battery)}
                    className={`text-left px-3 py-2.5 rounded-xl text-sm transition-colors ${
                      formData.batteryCapacity === preset.battery
                        ? 'bg-primary-600/10 text-primary-400 border border-primary-500/20'
                        : 'bg-carbon-800/50 text-carbon-300 hover:bg-carbon-800 border border-transparent'
                    }`}
                  >
                    <span className="font-medium">{preset.label}</span>
                    <span className="block text-[11px] text-carbon-500 mt-0.5">{preset.battery} kWh · {preset.range} km</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Calculator form */}
            <form onSubmit={handleCalculate} className="card space-y-5">
              <h3 className="text-sm font-semibold text-carbon-300">Charging Parameters</h3>

              <div>
                <label className="label-text">Battery Capacity (kWh)</label>
                <input
                  type="number"
                  step="0.1"
                  value={formData.batteryCapacity}
                  onChange={(e) => handleChange('batteryCapacity', e.target.value)}
                  className="input-field"
                />
              </div>

              <div>
                <label className="label-text">Current Battery: {formData.currentPercent}%</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={formData.currentPercent}
                  onChange={(e) => handleChange('currentPercent', Number(e.target.value))}
                  className="w-full accent-red-500"
                />
                <div className="w-full bg-carbon-800 rounded-full h-2 mt-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-red-500 via-volt-400 to-primary-500 transition-all"
                    style={{ width: `${formData.currentPercent}%` }}
                  />
                </div>
              </div>

              <div>
                <label className="label-text">Target Battery: {formData.targetPercent}%</label>
                <input
                  type="range"
                  min="0"
                  max="100"
                  value={formData.targetPercent}
                  onChange={(e) => handleChange('targetPercent', Number(e.target.value))}
                  className="w-full accent-primary-500"
                />
                <div className="w-full bg-carbon-800 rounded-full h-2 mt-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-primary-600 to-primary-400 transition-all"
                    style={{ width: `${formData.targetPercent}%` }}
                  />
                </div>
              </div>

              <div>
                <label className="label-text">Charger Type</label>
                <select
                  value={formData.chargerLevel}
                  onChange={(e) => handleChange('chargerLevel', e.target.value)}
                  className="input-field"
                >
                  <option value="Level 1">Level 1 (~1.4 kW)</option>
                  <option value="Level 2">Level 2 (~7.2 kW)</option>
                  <option value="DC Fast Charger">DC Fast Charger (~50 kW)</option>
                </select>
              </div>

              <div>
                <label className="label-text">Price per kWh ($AUD)</label>
                <input
                  type="number"
                  step="0.01"
                  value={formData.pricePerKWh}
                  onChange={(e) => handleChange('pricePerKWh', e.target.value)}
                  className="input-field"
                />
              </div>

              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? 'Calculating...' : 'Calculate'}
              </button>
            </form>

            {error && <ErrorMessage message={error} />}
          </div>

          {/* Results */}
          <div className="space-y-6">
            {result ? (
              <>
                {/* Main result */}
                <div className="card animate-slide-up">
                  <h3 className="text-sm font-semibold text-carbon-300 mb-4">Charging Result</h3>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="bg-gradient-to-br from-primary-600/10 to-primary-800/5 rounded-2xl p-5 text-center border border-primary-500/10">
                      <div className="w-10 h-10 rounded-xl bg-primary-500/10 flex items-center justify-center mx-auto mb-3">
                        <svg className="w-5 h-5 text-primary-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <p className="text-2xl font-bold text-white">{result.charging.chargingTime}</p>
                      <p className="text-xs text-carbon-500 mt-1">Charging Time</p>
                    </div>

                    <div className="bg-gradient-to-br from-volt-600/10 to-volt-800/5 rounded-2xl p-5 text-center border border-volt-500/10">
                      <div className="w-10 h-10 rounded-xl bg-volt-500/10 flex items-center justify-center mx-auto mb-3">
                        <svg className="w-5 h-5 text-volt-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.659c1.171.879 3.07.879 4.242 0 1.172-.879 1.172-2.303 0-3.182C13.536 12.219 12.768 12 12 12c-.725 0-1.45-.22-2.003-.659-1.106-.879-1.106-2.303 0-3.182s2.9-.879 4.006 0l.415.33M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                      </div>
                      <p className="text-2xl font-bold text-white">
                        {result.cost ? formatCurrency(result.cost.totalCost) : 'N/A'}
                      </p>
                      <p className="text-xs text-carbon-500 mt-1">Estimated Cost</p>
                    </div>

                    <div className="bg-gradient-to-br from-blue-600/10 to-blue-800/5 rounded-2xl p-5 text-center border border-blue-500/10">
                      <div className="w-10 h-10 rounded-xl bg-blue-500/10 flex items-center justify-center mx-auto mb-3">
                        <svg className="w-5 h-5 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
                        </svg>
                      </div>
                      <p className="text-2xl font-bold text-white">{result.charging.energyRequired}</p>
                      <p className="text-xs text-carbon-500 mt-1">kWh Required</p>
                    </div>
                  </div>
                </div>

                {/* All charger levels comparison */}
                {quickResult && (
                  <div className="card animate-slide-up" style={{ animationDelay: '0.1s' }}>
                    <h3 className="text-sm font-semibold text-carbon-300 mb-4">Compare All Charger Types</h3>
                    <div className="space-y-3">
                      {quickResult.estimates?.map((est, idx) => {
                        const maxTime = Math.max(...quickResult.estimates.map((e) => e.chargingTimeMinutes));
                        const barWidth = maxTime > 0 ? (est.chargingTimeMinutes / maxTime) * 100 : 0;
                        const colors = ['bg-blue-500', 'bg-primary-500', 'bg-volt-500'];
                        return (
                          <div key={idx}>
                            <div className="flex items-center justify-between mb-1.5">
                              <span className="text-sm text-carbon-300">{est.chargerLevel}</span>
                              <span className="text-sm font-semibold text-white">{est.chargingTime}</span>
                            </div>
                            <div className="w-full bg-carbon-800 rounded-full h-2.5">
                              <div
                                className={`h-2.5 rounded-full ${colors[idx]} transition-all duration-700`}
                                style={{ width: `${barWidth}%` }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    <div className="mt-4 pt-4 border-t border-carbon-800">
                      <p className="text-xs text-carbon-500">
                        Total energy required: <span className="text-white font-medium">{quickResult.energyRequired} kWh</span>
                      </p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              /* Placeholder */
              <div className="card flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 rounded-2xl bg-carbon-800 flex items-center justify-center mb-4">
                  <svg className="w-8 h-8 text-carbon-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15.59 14.37a6 6 0 01-5.84 7.38v-4.8m5.84-2.58a14.98 14.98 0 006.16-12.12A14.98 14.98 0 009.631 8.41m5.96 5.96a14.926 14.926 0 01-5.841 2.58m-.119-8.54a6 6 0 00-7.381 5.84h4.8m2.581-5.84a14.927 14.927 0 00-2.58 5.84m2.699 2.7c-.103.021-.207.041-.311.06a15.09 15.09 0 01-2.448-2.448 14.9 14.9 0 01.06-.312m-2.24 2.39a4.493 4.493 0 00-1.757 4.306 4.493 4.493 0 004.306-1.758M16.5 9a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0z" />
                  </svg>
                </div>
                <p className="text-carbon-500 text-sm">Enter your charging parameters and click Calculate</p>
                <p className="text-carbon-600 text-xs mt-1">Results will appear here</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalculatorPage;
