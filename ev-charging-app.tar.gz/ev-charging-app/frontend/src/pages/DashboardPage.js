import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { favoritesService, notificationService } from '../services/miscServices';
import StationCard from '../components/Station/StationCard';
import { LoadingSpinner, EmptyState, ErrorMessage } from '../components/Common/SharedComponents';
import { timeAgo } from '../utils/helpers';

/**
 * User Dashboard
 * Shows favorites, notifications, recent searches, and profile info.
 */
const DashboardPage = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState('favorites');
  const [favorites, setFavorites] = useState([]);
  const [notifications, setNotifications] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const tabs = [
    { id: 'favorites', label: 'Favorites' },
    { id: 'notifications', label: 'Notifications' },
    { id: 'profile', label: 'Profile' },
  ];

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        if (activeTab === 'favorites') {
          const res = await favoritesService.getAll();
          setFavorites(res.data || []);
        } else if (activeTab === 'notifications') {
          const res = await notificationService.getAll();
          setNotifications(res.data || []);
        }
      } catch (err) {
        setError('Failed to load data');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [activeTab]);

  const handleRemoveFavorite = async (stationId) => {
    try {
      await favoritesService.remove(stationId);
      setFavorites((prev) => prev.filter((s) => s._id !== stationId));
    } catch (err) {
      console.error('Remove favorite failed:', err);
    }
  };

  const handleMarkAllRead = async () => {
    try {
      await notificationService.markAllAsRead();
      setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
    } catch (err) {
      console.error('Mark all read failed:', err);
    }
  };

  return (
    <div className="min-h-screen pt-16 bg-carbon-950">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="section-title">Dashboard</h1>
          <p className="section-subtitle mt-1">Welcome back, {user?.name}</p>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-carbon-900 p-1 rounded-xl mb-6 w-fit border border-carbon-800">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                activeTab === tab.id
                  ? 'bg-primary-600 text-white shadow-glow'
                  : 'text-carbon-400 hover:text-white'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {error && <ErrorMessage message={error} />}

        {/* Favorites tab */}
        {activeTab === 'favorites' && (
          <div>
            {loading ? (
              <LoadingSpinner message="Loading favorites..." />
            ) : favorites.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {favorites.map((station) => (
                  <div key={station._id} className="relative group">
                    <StationCard station={station} showDistance={false} />
                    <button
                      onClick={() => handleRemoveFavorite(station._id)}
                      className="absolute top-3 right-3 p-1.5 rounded-lg bg-carbon-800/80 text-carbon-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                      title="Remove from favorites"
                    >
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                      </svg>
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="No favorites yet"
                message="Save your favourite charging stations for quick access"
              />
            )}
          </div>
        )}

        {/* Notifications tab */}
        {activeTab === 'notifications' && (
          <div>
            {notifications.length > 0 && (
              <div className="flex justify-end mb-3">
                <button onClick={handleMarkAllRead} className="text-xs text-primary-400 hover:text-primary-300">
                  Mark all as read
                </button>
              </div>
            )}
            {loading ? (
              <LoadingSpinner message="Loading notifications..." />
            ) : notifications.length > 0 ? (
              <div className="space-y-2">
                {notifications.map((notif) => (
                  <div
                    key={notif._id}
                    className={`card !p-4 flex items-start gap-3 ${!notif.isRead ? 'border-primary-800/30 bg-primary-950/20' : ''}`}
                  >
                    <div className={`w-2 h-2 rounded-full flex-shrink-0 mt-2 ${notif.isRead ? 'bg-carbon-700' : 'bg-primary-400'}`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-white">{notif.title}</p>
                      <p className="text-xs text-carbon-500 mt-0.5">{notif.message}</p>
                      <p className="text-[11px] text-carbon-600 mt-1.5">{timeAgo(notif.createdAt)}</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState
                title="No notifications"
                message="You're all caught up!"
              />
            )}
          </div>
        )}

        {/* Profile tab */}
        {activeTab === 'profile' && (
          <div className="card max-w-lg">
            <h3 className="text-base font-semibold text-white mb-4">Profile Information</h3>
            <div className="space-y-4">
              <div>
                <label className="label-text">Name</label>
                <p className="text-sm text-white">{user?.name}</p>
              </div>
              <div>
                <label className="label-text">Email</label>
                <p className="text-sm text-white">{user?.email}</p>
              </div>
              <div>
                <label className="label-text">Role</label>
                <span className={`badge ${user?.role === 'admin' ? 'badge-yellow' : 'badge-green'}`}>
                  {user?.role}
                </span>
              </div>
              {user?.vehicle?.make && (
                <div>
                  <label className="label-text">Vehicle</label>
                  <p className="text-sm text-white">
                    {user.vehicle.make} {user.vehicle.model} ({user.vehicle.year})
                  </p>
                  <p className="text-xs text-carbon-500 mt-0.5">
                    {user.vehicle.batteryCapacity} kWh · {user.vehicle.range} km range
                  </p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;
