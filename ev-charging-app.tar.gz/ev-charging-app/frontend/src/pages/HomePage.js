import React, { useState, useEffect, useCallback } from 'react';
import MapView from '../components/Map/MapView';
import StationCard from '../components/Station/StationCard';
import StationDetail from '../components/Station/StationDetail';
import { LoadingSpinner, ErrorMessage } from '../components/Common/SharedComponents';
import { useGeolocation, useDebounce } from '../hooks/useCustomHooks';
import stationService from '../services/stationService';

/**
 * Home Page
 * Main map view with station search, filters, and detail panel.
 */
const HomePage = () => {
  const { location: userLocation, loading: geoLoading } = useGeolocation();
  const [stations, setStations] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedStation, setSelectedStation] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState({
    chargerLevel: '',
    connectorType: '',
    radius: 50,
  });
  const [showFilters, setShowFilters] = useState(false);

  const debouncedSearch = useDebounce(searchQuery, 400);

  // Fetch nearby stations
  const fetchStations = useCallback(async () => {
    if (!userLocation) return;
    setLoading(true);
    setError(null);

    try {
      const params = {
        lat: userLocation.lat,
        lng: userLocation.lng,
        radius: filters.radius,
      };
      if (filters.chargerLevel) params.chargerLevel = filters.chargerLevel;
      if (filters.connectorType) params.connectorType = filters.connectorType;

      const response = await stationService.getNearby(
        params.lat,
        params.lng,
        params.radius,
        params
      );
      setStations(response.data || []);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to fetch stations');
    } finally {
      setLoading(false);
    }
  }, [userLocation, filters]);

  useEffect(() => {
    fetchStations();
  }, [fetchStations]);

  // Search stations
  useEffect(() => {
    if (!debouncedSearch) {
      fetchStations();
      return;
    }

    const searchStations = async () => {
      setLoading(true);
      try {
        const response = await stationService.getAll({ search: debouncedSearch });
        setStations(response.data || []);
      } catch (err) {
        setError('Search failed');
      } finally {
        setLoading(false);
      }
    };

    searchStations();
  }, [debouncedSearch, fetchStations]);

  const handleStationClick = (station) => {
    setSelectedStation(station);
  };

  const clearFilters = () => {
    setFilters({ chargerLevel: '', connectorType: '', radius: 50 });
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen pt-16">
      <div className="flex flex-col lg:flex-row h-[calc(100vh-64px)]">
        {/* Sidebar */}
        <div className="w-full lg:w-[420px] flex-shrink-0 border-r border-carbon-800 flex flex-col bg-carbon-950 overflow-hidden">
          {/* Search */}
          <div className="p-4 border-b border-carbon-800 space-y-3">
            <div className="relative">
              <svg className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-carbon-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              <input
                type="text"
                placeholder="Search stations, cities, or addresses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field pl-10 pr-10 text-sm"
              />
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-carbon-500 hover:text-white"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>

            {/* Filter toggle */}
            <div className="flex items-center justify-between">
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="btn-ghost text-xs !px-3 !py-1.5"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6h9.75M10.5 6a1.5 1.5 0 11-3 0m3 0a1.5 1.5 0 10-3 0M3.75 6H7.5m3 12h9.75m-9.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-3.75 0H7.5m9-6h3.75m-3.75 0a1.5 1.5 0 01-3 0m3 0a1.5 1.5 0 00-3 0m-9.75 0h9.75" />
                </svg>
                Filters
              </button>
              <span className="text-xs text-carbon-500">
                {stations.length} station{stations.length !== 1 ? 's' : ''} found
              </span>
            </div>

            {/* Filters panel */}
            {showFilters && (
              <div className="space-y-3 pt-2 animate-fade-in">
                <div>
                  <label className="label-text text-xs">Charger Level</label>
                  <select
                    value={filters.chargerLevel}
                    onChange={(e) => setFilters({ ...filters, chargerLevel: e.target.value })}
                    className="input-field text-sm !py-2"
                  >
                    <option value="">All Levels</option>
                    <option value="Level 1">Level 1 (Slow)</option>
                    <option value="Level 2">Level 2 (Standard)</option>
                    <option value="DC Fast Charger">DC Fast Charger</option>
                  </select>
                </div>
                <div>
                  <label className="label-text text-xs">Connector Type</label>
                  <select
                    value={filters.connectorType}
                    onChange={(e) => setFilters({ ...filters, connectorType: e.target.value })}
                    className="input-field text-sm !py-2"
                  >
                    <option value="">All Types</option>
                    <option value="Type 2">Type 2</option>
                    <option value="CCS2">CCS2</option>
                    <option value="CHAdeMO">CHAdeMO</option>
                    <option value="Tesla Supercharger">Tesla Supercharger</option>
                  </select>
                </div>
                <div>
                  <label className="label-text text-xs">Radius: {filters.radius} km</label>
                  <input
                    type="range"
                    min="5"
                    max="200"
                    value={filters.radius}
                    onChange={(e) => setFilters({ ...filters, radius: Number(e.target.value) })}
                    className="w-full accent-primary-500"
                  />
                </div>
                <button onClick={clearFilters} className="text-xs text-primary-400 hover:text-primary-300">
                  Clear all filters
                </button>
              </div>
            )}
          </div>

          {/* Station list */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {loading && <LoadingSpinner message="Finding stations..." />}
            {error && <ErrorMessage message={error} onRetry={fetchStations} />}

            {!loading && !error && stations.length === 0 && (
              <div className="text-center py-12">
                <p className="text-carbon-500 text-sm">No stations found.</p>
                <p className="text-carbon-600 text-xs mt-1">Try expanding your search radius.</p>
              </div>
            )}

            {!loading &&
              stations.map((station) => (
                <StationCard
                  key={station._id}
                  station={station}
                  onClick={handleStationClick}
                  compact
                />
              ))}
          </div>
        </div>

        {/* Map area */}
        <div className="flex-1 relative">
          {geoLoading ? (
            <div className="h-full flex items-center justify-center bg-carbon-900">
              <LoadingSpinner size="lg" message="Getting your location..." />
            </div>
          ) : (
            <MapView
              center={
                userLocation
                  ? [userLocation.lat, userLocation.lng]
                  : [-33.8688, 151.2093]
              }
              zoom={12}
              stations={stations}
              userLocation={userLocation}
              selectedStation={selectedStation}
              onStationClick={handleStationClick}
              className="h-full"
            />
          )}

          {/* Station detail overlay */}
          {selectedStation && (
            <div className="absolute top-4 right-4 w-[380px] max-h-[calc(100%-32px)] overflow-y-auto z-[1000]">
              <StationDetail
                station={selectedStation}
                onClose={() => setSelectedStation(null)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
