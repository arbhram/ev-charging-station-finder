import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import Navbar from './components/Common/Navbar';
import { ProtectedRoute } from './components/Common/SharedComponents';

// Pages
import HomePage from './pages/HomePage';
import RoutePlannerPage from './pages/RoutePlannerPage';
import CalculatorPage from './pages/CalculatorPage';
import CompatibilityPage from './pages/CompatibilityPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import DashboardPage from './pages/DashboardPage';
import AdminPage from './pages/AdminPage';

/**
 * App Component
 * Root application component with routing, context providers, and layout.
 */
function App() {
  return (
    <AuthProvider>
      <SocketProvider>
        <Router>
          <div className="min-h-screen bg-carbon-950">
            <Navbar />
            <Routes>
              {/* Public routes */}
              <Route path="/" element={<HomePage />} />
              <Route path="/route-planner" element={<RoutePlannerPage />} />
              <Route path="/calculator" element={<CalculatorPage />} />
              <Route path="/compatibility" element={<CompatibilityPage />} />
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />

              {/* Protected routes */}
              <Route
                path="/dashboard"
                element={
                  <ProtectedRoute>
                    <DashboardPage />
                  </ProtectedRoute>
                }
              />

              {/* Admin routes */}
              <Route
                path="/admin"
                element={
                  <ProtectedRoute adminOnly>
                    <AdminPage />
                  </ProtectedRoute>
                }
              />

              {/* 404 fallback */}
              <Route
                path="*"
                element={
                  <div className="min-h-screen pt-16 flex items-center justify-center">
                    <div className="text-center">
                      <h1 className="text-6xl font-bold text-carbon-700 mb-4">404</h1>
                      <p className="text-carbon-500 mb-6">Page not found</p>
                      <a href="/" className="btn-primary">Go Home</a>
                    </div>
                  </div>
                }
              />
            </Routes>
          </div>
        </Router>
      </SocketProvider>
    </AuthProvider>
  );
}

export default App;
