import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { favoritesService } from '../../services/miscServices';
import { formatCurrency, getChargerLevelInfo, getStatusInfo } from '../../utils/helpers';

/**
 * Detailed station info panel shown when a station is selected.
 */
const StationDetail = ({ station, onClose }) => {
  const { isAuthenticated } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [favoriteLoading, setFavoriteLoading] = useState(false);

  useEffect(() => {
    if (isAuthenticated && station?._id) {
      favoritesService.check(station._id).then((res) => {
        setIsFavorite(res.data.isFavorite);
      }).catch(() => {});
    }
  }, [station, isAuthenticated]);

  const toggleFavorite = async () => {
    if (!isAuthenticated) return;
    setFavoriteLoading(true);
    try {
      if (isFavorite) {
        await favoritesService.remove(station._id);
        setIsFavorite(false);
      } else {
        await favoritesService.add(station._id);
        setIsFavorite(true);
      }
    } catch (err) {
      console.error('Favorite toggle error:', err);
    } finally {
      setFavoriteLoading(false);
    }
  };

  if (!station) return null;

  const levelInfo = getChargerLevelInfo(station.chargerLevel);

  return (
    <div className="bg-carbon-900 border border-carbon-800 rounded-2xl overflow-hidden animate-slide-up">
      {/* Header */}
      <div className="p-5 border-b border-carbon-800">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h2 className="text-lg font-bold text-white">{station.name}</h2>
            <p className="text-carbon-500 text-sm mt-1">
              {station.location?.formattedAddress}
            </p>
          </div>
          <div className="flex items-center gap-2">
            {isAuthenticated && (
              <button
                onClick={toggleFavorite}
                disabled={favoriteLoading}
                className="p-2 rounded-xl hover:bg-carbon-800 transition-colors"
              >
                <svg
                  className={`w-5 h-5 ${isFavorite ? 'text-red-400 fill-current' : 'text-carbon-500'}`}
                  fill={isFavorite ? 'currentColor' : 'none'}
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                  strokeWidth={1.5}
                >
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 8.25c0-2.485-2.099-4.5-4.688-4.5-1.935 0-3.597 1.126-4.312 2.733-.715-1.607-2.377-2.733-4.313-2.733C5.1 3.75 3 5.765 3 8.25c0 7.22 9 12 9 12s9-4.78 9-12z" />
                </svg>
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 rounded-xl hover:bg-carbon-800 text-carbon-500 hover:text-white transition-colors"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-3 mt-4">
          <div className="bg-carbon-800/50 rounded-xl p-3 text-center">
            <p className={`text-sm font-semibold ${levelInfo.color}`}>{station.chargerLevel}</p>
            <p className="text-[11px] text-carbon-500 mt-0.5">{levelInfo.speed}</p>
          </div>
          <div className="bg-carbon-800/50 rounded-xl p-3 text-center">
            <p className="text-sm font-semibold text-white">
              {station.pricing?.isFree ? 'Free' : formatCurrency(station.pricing?.perKWh || 0)}
            </p>
            <p className="text-[11px] text-carbon-500 mt-0.5">{station.pricing?.isFree ? '' : 'per kWh'}</p>
          </div>
          <div className="bg-carbon-800/50 rounded-xl p-3 text-center">
            <p className="text-sm font-semibold text-white">
              {station.rating?.average?.toFixed(1) || 'N/A'}
            </p>
            <p className="text-[11px] text-carbon-500 mt-0.5">{station.rating?.count || 0} reviews</p>
          </div>
        </div>
      </div>

      {/* Connectors */}
      <div className="p-5 border-b border-carbon-800">
        <h3 className="text-sm font-semibold text-carbon-300 mb-3">Connectors</h3>
        <div className="space-y-2">
          {station.connectors?.map((connector, idx) => {
            const statusInfo = getStatusInfo(connector.status);
            return (
              <div key={idx} className="flex items-center justify-between bg-carbon-800/30 rounded-xl p-3">
                <div className="flex items-center gap-3">
                  <div className={`w-2 h-2 rounded-full ${connector.available > 0 ? 'bg-primary-400' : 'bg-red-400'}`} />
                  <div>
                    <p className="text-sm font-medium text-white">{connector.type}</p>
                    <p className="text-xs text-carbon-500">{connector.powerKW} kW</p>
                  </div>
                </div>
                <div className="text-right">
                  <span className={`text-xs font-medium ${statusInfo.color}`}>
                    {connector.available}/{connector.quantity}
                  </span>
                  <p className="text-[11px] text-carbon-600">{statusInfo.label}</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Operator */}
      {station.operator?.name && (
        <div className="p-5 border-b border-carbon-800">
          <h3 className="text-sm font-semibold text-carbon-300 mb-2">Operator</h3>
          <p className="text-sm text-white">{station.operator.name}</p>
          {station.operator.website && (
            <a
              href={station.operator.website}
              target="_blank"
              rel="noopener noreferrer"
              className="text-xs text-primary-400 hover:text-primary-300 mt-1 inline-block"
            >
              Visit website →
            </a>
          )}
        </div>
      )}

      {/* Amenities */}
      {station.amenities?.length > 0 && (
        <div className="p-5">
          <h3 className="text-sm font-semibold text-carbon-300 mb-3">Amenities</h3>
          <div className="flex flex-wrap gap-2">
            {station.amenities.map((amenity, idx) => (
              <span key={idx} className="px-3 py-1 bg-carbon-800 text-carbon-300 text-xs rounded-lg">
                {amenity}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default StationDetail;
