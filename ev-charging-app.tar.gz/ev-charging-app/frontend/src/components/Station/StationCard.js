import React from 'react';
import { formatDistance, formatCurrency, getChargerLevelInfo, getStatusInfo } from '../../utils/helpers';

/**
 * Station card component for lists and search results.
 */
const StationCard = ({ station, onClick, compact = false, showDistance = true }) => {
  const levelInfo = getChargerLevelInfo(station.chargerLevel);
  const availableCount = station.connectors?.reduce((sum, c) => sum + (c.available || 0), 0) || 0;
  const totalCount = station.connectors?.reduce((sum, c) => sum + (c.quantity || 0), 0) || 0;
  const isAvailable = availableCount > 0;

  return (
    <div
      onClick={() => onClick && onClick(station)}
      className={`card-glow cursor-pointer group ${compact ? 'p-4' : 'p-5'}`}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1 min-w-0">
          {/* Station name */}
          <h3 className={`font-semibold text-white group-hover:text-primary-400 transition-colors truncate ${compact ? 'text-sm' : 'text-base'}`}>
            {station.name}
          </h3>

          {/* Address */}
          <p className="text-carbon-500 text-xs mt-1 truncate">
            {station.location?.formattedAddress || station.location?.address?.city || 'Location not specified'}
          </p>

          {/* Charger level and availability */}
          <div className="flex items-center gap-3 mt-3">
            <span className={`text-xs font-medium ${levelInfo.color}`}>
              {levelInfo.label}
            </span>
            <span className="text-carbon-700">|</span>
            <span className={`text-xs font-medium ${isAvailable ? 'text-primary-400' : 'text-red-400'}`}>
              {availableCount}/{totalCount} available
            </span>
          </div>

          {/* Connectors */}
          <div className="flex flex-wrap gap-1.5 mt-3">
            {station.connectors?.map((connector, idx) => {
              const statusInfo = getStatusInfo(connector.status);
              return (
                <span
                  key={idx}
                  className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-md text-[11px] font-medium ${statusInfo.bg} ${statusInfo.color} border border-current/10`}
                >
                  {connector.type} · {connector.powerKW}kW
                </span>
              );
            })}
          </div>
        </div>

        {/* Right side — price & distance */}
        <div className="flex flex-col items-end gap-2 flex-shrink-0">
          {/* Price */}
          <div className="text-right">
            {station.pricing?.isFree ? (
              <span className="badge-green">Free</span>
            ) : station.pricing?.perKWh ? (
              <span className="text-sm font-semibold text-white">
                {formatCurrency(station.pricing.perKWh)}
                <span className="text-carbon-500 text-xs font-normal">/kWh</span>
              </span>
            ) : null}
          </div>

          {/* Distance */}
          {showDistance && station.distance != null && (
            <span className="text-xs text-carbon-400">
              {formatDistance(station.distance)}
            </span>
          )}

          {/* Rating */}
          {station.rating?.average > 0 && (
            <div className="flex items-center gap-1">
              <svg className="w-3.5 h-3.5 text-volt-400" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
              </svg>
              <span className="text-xs text-carbon-400">{station.rating.average.toFixed(1)}</span>
            </div>
          )}
        </div>
      </div>

      {/* Amenities */}
      {!compact && station.amenities?.length > 0 && (
        <div className="flex flex-wrap gap-1.5 mt-3 pt-3 border-t border-carbon-800">
          {station.amenities.slice(0, 5).map((amenity, idx) => (
            <span key={idx} className="text-[10px] px-2 py-0.5 bg-carbon-800 text-carbon-400 rounded-md">
              {amenity}
            </span>
          ))}
          {station.amenities.length > 5 && (
            <span className="text-[10px] px-2 py-0.5 text-carbon-500">
              +{station.amenities.length - 5} more
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default StationCard;
