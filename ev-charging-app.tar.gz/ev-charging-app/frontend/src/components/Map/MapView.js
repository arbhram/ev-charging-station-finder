import React, { useEffect, useRef, useState } from 'react';

/**
 * Interactive map component using Leaflet.
 * Displays charging station markers with popups.
 * Falls back gracefully if Leaflet isn't loaded.
 */
const MapView = ({
  center = [-33.8688, 151.2093],
  zoom = 12,
  stations = [],
  onStationClick,
  userLocation = null,
  routeCoordinates = null,
  selectedStation = null,
  className = '',
}) => {
  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markersRef = useRef([]);
  const [mapReady, setMapReady] = useState(false);

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || mapInstanceRef.current) return;

    // Check if Leaflet is available
    const L = window.L;
    if (!L) {
      console.error('Leaflet not loaded');
      return;
    }

    const map = L.map(mapRef.current, {
      center: center,
      zoom: zoom,
      zoomControl: false,
      attributionControl: true,
    });

    // Dark tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
      maxZoom: 19,
    }).addTo(map);

    // Zoom control position
    L.control.zoom({ position: 'bottomright' }).addTo(map);

    mapInstanceRef.current = map;
    setMapReady(true);

    return () => {
      map.remove();
      mapInstanceRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Update center when props change
  useEffect(() => {
    if (mapInstanceRef.current && center) {
      mapInstanceRef.current.setView(center, zoom);
    }
  }, [center, zoom]);

  // User location marker
  useEffect(() => {
    if (!mapInstanceRef.current || !userLocation) return;
    const L = window.L;
    if (!L) return;

    const userIcon = L.divIcon({
      html: `<div style="width:16px;height:16px;background:#3b82f6;border:3px solid white;border-radius:50%;box-shadow:0 0 12px rgba(59,130,246,0.5);"></div>`,
      className: '',
      iconSize: [16, 16],
      iconAnchor: [8, 8],
    });

    const marker = L.marker([userLocation.lat, userLocation.lng], {
      icon: userIcon,
    }).addTo(mapInstanceRef.current);

    marker.bindPopup('<b>Your Location</b>');

    return () => marker.remove();
  }, [userLocation, mapReady]);

  // Station markers
  useEffect(() => {
    if (!mapInstanceRef.current || !mapReady) return;
    const L = window.L;
    if (!L) return;

    // Clear existing markers
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    stations.forEach((station) => {
      const [lng, lat] = station.location?.coordinates || [0, 0];
      if (!lat && !lng) return;

      const isSelected =
        selectedStation && selectedStation._id === station._id;
      const hasAvailable = station.connectors?.some((c) => c.available > 0);

      const color = isSelected
        ? '#f59e0b'
        : hasAvailable
          ? '#10b981'
          : '#ef4444';

      const stationIcon = L.divIcon({
        html: `
          <div style="
            width:${isSelected ? 36 : 28}px;
            height:${isSelected ? 36 : 28}px;
            background:${color};
            border:2px solid white;
            border-radius:8px;
            display:flex;
            align-items:center;
            justify-content:center;
            box-shadow:0 2px 8px rgba(0,0,0,0.3);
            transition:transform 0.2s;
            cursor:pointer;
          ">
            <svg width="14" height="14" viewBox="0 0 24 24" fill="white" stroke="none">
              <path d="M13 10V3L4 14h7v7l9-11h-7z"/>
            </svg>
          </div>
        `,
        className: '',
        iconSize: [isSelected ? 36 : 28, isSelected ? 36 : 28],
        iconAnchor: [isSelected ? 18 : 14, isSelected ? 18 : 14],
      });

      const marker = L.marker([lat, lng], { icon: stationIcon }).addTo(
        mapInstanceRef.current
      );

      // Popup content
      const availableCount = station.connectors?.reduce(
        (sum, c) => sum + (c.available || 0),
        0
      ) || 0;
      const totalCount = station.connectors?.reduce(
        (sum, c) => sum + (c.quantity || 0),
        0
      ) || 0;
      const connectorTypes = station.connectors?.map((c) => c.type).join(', ') || 'N/A';
      const price = station.pricing?.isFree
        ? 'Free'
        : station.pricing?.perKWh
          ? `$${station.pricing.perKWh}/kWh`
          : 'N/A';
      const distance = station.distance
        ? `${station.distance.toFixed(1)} km`
        : '';

      marker.bindPopup(`
        <div style="font-family:'DM Sans',sans-serif;min-width:200px;padding:4px;">
          <h3 style="font-weight:600;font-size:14px;margin-bottom:6px;color:#111;">${station.name}</h3>
          <div style="font-size:12px;color:#555;line-height:1.6;">
            <div><b>Level:</b> ${station.chargerLevel || 'N/A'}</div>
            <div><b>Connectors:</b> ${connectorTypes}</div>
            <div><b>Available:</b> ${availableCount}/${totalCount}</div>
            <div><b>Price:</b> ${price}</div>
            ${distance ? `<div><b>Distance:</b> ${distance}</div>` : ''}
          </div>
        </div>
      `);

      marker.on('click', () => {
        if (onStationClick) onStationClick(station);
      });

      markersRef.current.push(marker);
    });
  }, [stations, selectedStation, mapReady, onStationClick]);

  // Route polyline
  useEffect(() => {
    if (!mapInstanceRef.current || !routeCoordinates || !mapReady) return;
    const L = window.L;
    if (!L) return;

    const polyline = L.polyline(routeCoordinates, {
      color: '#10b981',
      weight: 4,
      opacity: 0.8,
      dashArray: '10, 10',
    }).addTo(mapInstanceRef.current);

    mapInstanceRef.current.fitBounds(polyline.getBounds(), { padding: [50, 50] });

    return () => polyline.remove();
  }, [routeCoordinates, mapReady]);

  return (
    <div className={`relative rounded-2xl overflow-hidden border border-carbon-800 ${className}`}>
      <div ref={mapRef} className="w-full h-full" style={{ minHeight: '400px' }} />
      {!mapReady && (
        <div className="absolute inset-0 flex items-center justify-center bg-carbon-900">
          <div className="text-carbon-500 text-sm">Loading map...</div>
        </div>
      )}
    </div>
  );
};

export default MapView;
