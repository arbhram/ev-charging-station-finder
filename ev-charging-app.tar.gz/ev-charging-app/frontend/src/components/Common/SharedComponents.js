import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

/**
 * Reusable loading spinner.
 */
export const LoadingSpinner = ({ size = 'md', message = '' }) => {
  const sizeClasses = {
    sm: 'w-5 h-5',
    md: 'w-8 h-8',
    lg: 'w-12 h-12',
  };

  return (
    <div className="flex flex-col items-center justify-center gap-3 py-8">
      <div className={`${sizeClasses[size]} animate-spin`}>
        <svg viewBox="0 0 24 24" fill="none" className="text-primary-500">
          <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeOpacity="0.2" />
          <path d="M12 2a10 10 0 019.95 9" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
        </svg>
      </div>
      {message && <p className="text-carbon-400 text-sm">{message}</p>}
    </div>
  );
};

/**
 * Protected route wrapper — redirects to login if not authenticated.
 */
export const ProtectedRoute = ({ children, adminOnly = false }) => {
  const { isAuthenticated, user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" message="Loading..." />
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (adminOnly && user?.role !== 'admin') {
    return <Navigate to="/" replace />;
  }

  return children;
};

/**
 * Empty state component.
 */
export const EmptyState = ({ icon, title, message, action }) => (
  <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
    {icon && <div className="text-carbon-600 mb-4">{icon}</div>}
    <h3 className="text-lg font-semibold text-carbon-300 mb-2">{title}</h3>
    {message && <p className="text-carbon-500 text-sm max-w-sm mb-6">{message}</p>}
    {action && action}
  </div>
);

/**
 * Error display component.
 */
export const ErrorMessage = ({ message, onRetry }) => (
  <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-start gap-3">
    <svg className="w-5 h-5 text-red-400 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={1.5}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v3.75m9-.75a9 9 0 11-18 0 9 9 0 0118 0zm-9 3.75h.008v.008H12v-.008z" />
    </svg>
    <div className="flex-1">
      <p className="text-red-400 text-sm">{message}</p>
      {onRetry && (
        <button onClick={onRetry} className="text-red-300 text-sm underline mt-1 hover:text-red-200">
          Try again
        </button>
      )}
    </div>
  </div>
);
