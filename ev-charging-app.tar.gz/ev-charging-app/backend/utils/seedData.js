require('dotenv').config();
const mongoose = require('mongoose');
const { ChargingStation, Vehicle, User } = require('../models');
const bcrypt = require('bcryptjs');
const logger = require('./logger');

/**
 * Seed Script
 * Populates the database with sample data for development/testing.
 * Run: npm run seed
 */

const vehicles = [
  {
    make: 'Tesla',
    model: 'Model 3',
    year: 2024,
    batteryCapacity: 60,
    range: 491,
    efficiency: 0.122,
    compatibleConnectors: ['Type 2', 'CCS2', 'Tesla Supercharger', 'Tesla Destination'],
    maxChargingSpeed: { ac: 11, dc: 170 },
    category: 'sedan',
  },
  {
    make: 'Tesla',
    model: 'Model Y',
    year: 2024,
    batteryCapacity: 75,
    range: 533,
    efficiency: 0.141,
    compatibleConnectors: ['Type 2', 'CCS2', 'Tesla Supercharger', 'Tesla Destination'],
    maxChargingSpeed: { ac: 11, dc: 250 },
    category: 'suv',
  },
  {
    make: 'Nissan',
    model: 'Leaf',
    year: 2024,
    batteryCapacity: 40,
    range: 270,
    efficiency: 0.148,
    compatibleConnectors: ['Type 1', 'Type 2', 'CHAdeMO'],
    maxChargingSpeed: { ac: 6.6, dc: 50 },
    category: 'hatchback',
  },
  {
    make: 'BYD',
    model: 'Atto 3',
    year: 2024,
    batteryCapacity: 60.48,
    range: 420,
    efficiency: 0.144,
    compatibleConnectors: ['Type 2', 'CCS2'],
    maxChargingSpeed: { ac: 7, dc: 80 },
    category: 'suv',
  },
  {
    make: 'Hyundai',
    model: 'Ioniq 5',
    year: 2024,
    batteryCapacity: 77.4,
    range: 507,
    efficiency: 0.153,
    compatibleConnectors: ['Type 2', 'CCS2'],
    maxChargingSpeed: { ac: 11, dc: 233 },
    category: 'suv',
  },
  {
    make: 'Hyundai',
    model: 'Kona Electric',
    year: 2024,
    batteryCapacity: 64,
    range: 484,
    efficiency: 0.132,
    compatibleConnectors: ['Type 2', 'CCS2'],
    maxChargingSpeed: { ac: 11, dc: 100 },
    category: 'suv',
  },
  {
    make: 'Kia',
    model: 'EV6',
    year: 2024,
    batteryCapacity: 77.4,
    range: 528,
    efficiency: 0.147,
    compatibleConnectors: ['Type 2', 'CCS2'],
    maxChargingSpeed: { ac: 11, dc: 233 },
    category: 'suv',
  },
  {
    make: 'MG',
    model: 'ZS EV',
    year: 2024,
    batteryCapacity: 51,
    range: 320,
    efficiency: 0.159,
    compatibleConnectors: ['Type 2', 'CCS2'],
    maxChargingSpeed: { ac: 7, dc: 76 },
    category: 'suv',
  },
];

const stations = [
  {
    name: 'Sydney Olympic Park Charger Hub',
    location: {
      type: 'Point',
      coordinates: [151.0694, -33.8469],
      address: { street: '7 Figtree Dr', city: 'Sydney Olympic Park', state: 'NSW', postcode: '2127', country: 'Australia' },
      formattedAddress: '7 Figtree Dr, Sydney Olympic Park NSW 2127',
    },
    operator: { name: 'Chargefox', website: 'https://www.chargefox.com' },
    connectors: [
      { type: 'CCS2', powerKW: 350, quantity: 4, available: 3, status: 'available' },
      { type: 'CHAdeMO', powerKW: 50, quantity: 2, available: 2, status: 'available' },
      { type: 'Type 2', powerKW: 22, quantity: 4, available: 4, status: 'available' },
    ],
    chargerLevel: 'DC Fast Charger',
    pricing: { perKWh: 0.45, currency: 'AUD', isFree: false },
    amenities: ['WiFi', 'Restroom', 'Food', 'Parking', '24/7 Access'],
    rating: { average: 4.5, count: 128 },
    isVerified: true,
    dataSource: 'manual',
  },
  {
    name: 'Canberra Centre Fast Charger',
    location: {
      type: 'Point',
      coordinates: [149.1302, -35.2809],
      address: { street: '148 Bunda St', city: 'Canberra', state: 'ACT', postcode: '2601', country: 'Australia' },
      formattedAddress: '148 Bunda St, Canberra ACT 2601',
    },
    operator: { name: 'Evie Networks', website: 'https://www.evie.com.au' },
    connectors: [
      { type: 'CCS2', powerKW: 150, quantity: 2, available: 1, status: 'available' },
      { type: 'Type 2', powerKW: 22, quantity: 3, available: 3, status: 'available' },
    ],
    chargerLevel: 'DC Fast Charger',
    pricing: { perKWh: 0.40, currency: 'AUD', isFree: false },
    amenities: ['WiFi', 'Restroom', 'Food', 'Shopping', 'Parking'],
    rating: { average: 4.2, count: 87 },
    isVerified: true,
    dataSource: 'manual',
  },
  {
    name: 'Melbourne Central Tesla Supercharger',
    location: {
      type: 'Point',
      coordinates: [144.9631, -37.8136],
      address: { street: '300 Lonsdale St', city: 'Melbourne', state: 'VIC', postcode: '3000', country: 'Australia' },
      formattedAddress: '300 Lonsdale St, Melbourne VIC 3000',
    },
    operator: { name: 'Tesla', website: 'https://www.tesla.com' },
    connectors: [
      { type: 'Tesla Supercharger', powerKW: 250, quantity: 8, available: 5, status: 'available' },
      { type: 'CCS2', powerKW: 250, quantity: 4, available: 3, status: 'available' },
    ],
    chargerLevel: 'DC Fast Charger',
    pricing: { perKWh: 0.55, currency: 'AUD', isFree: false },
    amenities: ['WiFi', 'Restroom', 'Food', 'Shopping', 'Parking', '24/7 Access'],
    rating: { average: 4.7, count: 256 },
    isVerified: true,
    dataSource: 'manual',
  },
  {
    name: 'Goulburn Community Charger',
    location: {
      type: 'Point',
      coordinates: [149.7259, -34.7546],
      address: { street: '201 Auburn St', city: 'Goulburn', state: 'NSW', postcode: '2580', country: 'Australia' },
      formattedAddress: '201 Auburn St, Goulburn NSW 2580',
    },
    operator: { name: 'NRMA', website: 'https://www.mynrma.com.au' },
    connectors: [
      { type: 'CCS2', powerKW: 50, quantity: 2, available: 2, status: 'available' },
      { type: 'Type 2', powerKW: 7.2, quantity: 2, available: 1, status: 'available' },
    ],
    chargerLevel: 'DC Fast Charger',
    pricing: { perKWh: 0, currency: 'AUD', isFree: true },
    amenities: ['Restroom', 'Food', 'Parking', 'Lighting'],
    rating: { average: 4.0, count: 45 },
    isVerified: true,
    dataSource: 'manual',
  },
  {
    name: 'Bondi Junction Westfield Charger',
    location: {
      type: 'Point',
      coordinates: [151.2476, -33.8916],
      address: { street: '500 Oxford St', city: 'Bondi Junction', state: 'NSW', postcode: '2022', country: 'Australia' },
      formattedAddress: '500 Oxford St, Bondi Junction NSW 2022',
    },
    operator: { name: 'Evie Networks' },
    connectors: [
      { type: 'Type 2', powerKW: 22, quantity: 6, available: 4, status: 'available' },
      { type: 'CCS2', powerKW: 50, quantity: 2, available: 0, status: 'occupied' },
    ],
    chargerLevel: 'Level 2',
    pricing: { perKWh: 0.35, currency: 'AUD', isFree: false },
    amenities: ['WiFi', 'Restroom', 'Food', 'Shopping', 'Parking', 'Wheelchair Accessible'],
    rating: { average: 4.1, count: 73 },
    isVerified: true,
    dataSource: 'manual',
  },
  {
    name: 'Albury Wodonga Fast Charger',
    location: {
      type: 'Point',
      coordinates: [146.9135, -36.0737],
      address: { street: '555 Dean St', city: 'Albury', state: 'NSW', postcode: '2640', country: 'Australia' },
      formattedAddress: '555 Dean St, Albury NSW 2640',
    },
    operator: { name: 'Chargefox' },
    connectors: [
      { type: 'CCS2', powerKW: 350, quantity: 2, available: 2, status: 'available' },
      { type: 'CHAdeMO', powerKW: 50, quantity: 1, available: 1, status: 'available' },
    ],
    chargerLevel: 'DC Fast Charger',
    pricing: { perKWh: 0.45, currency: 'AUD', isFree: false },
    amenities: ['Restroom', 'Food', 'Parking', '24/7 Access', 'Lighting'],
    rating: { average: 4.3, count: 61 },
    isVerified: true,
    dataSource: 'manual',
  },
];

const seedDatabase = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    logger.info('Connected to MongoDB for seeding');

    // Clear existing data
    await Promise.all([
      ChargingStation.deleteMany({}),
      Vehicle.deleteMany({}),
      User.deleteMany({}),
    ]);
    logger.info('Cleared existing data');

    // Insert vehicles
    await Vehicle.insertMany(vehicles);
    logger.info(`Inserted ${vehicles.length} vehicles`);

    // Insert stations
    await ChargingStation.insertMany(stations);
    logger.info(`Inserted ${stations.length} charging stations`);

    // Create admin user
    const adminUser = await User.create({
      name: 'Admin User',
      email: 'admin@evcharging.com',
      password: 'Admin123!',
      role: 'admin',
    });
    logger.info(`Admin user created: ${adminUser.email}`);

    // Create demo user
    const demoUser = await User.create({
      name: 'Demo User',
      email: 'demo@evcharging.com',
      password: 'Demo123!',
      role: 'user',
      vehicle: {
        make: 'Tesla',
        model: 'Model 3',
        year: 2024,
        batteryCapacity: 60,
        range: 491,
        connectorType: 'CCS2',
      },
    });
    logger.info(`Demo user created: ${demoUser.email}`);

    logger.info('Database seeding completed successfully!');
    process.exit(0);
  } catch (error) {
    logger.error(`Seeding failed: ${error.message}`);
    process.exit(1);
  }
};

seedDatabase();
