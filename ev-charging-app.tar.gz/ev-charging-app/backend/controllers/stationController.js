const { ChargingStation } = require('../models');
const ApiError = require('../utils/ApiError');
const asyncHandler = require('../utils/asyncHandler');
const {
  calculateReachableDistance,
  filterReachableStations,
} = require('../utils/calculations');
const logger = require('../utils/logger');

/**
 * @desc    Get all charging stations with filtering, sorting, and pagination
 * @route   GET /api/stations
 * @access  Public
 */
const getStations = asyncHandler(async (req, res) => {
  const {
    page = 1,
    limit = 20,
    chargerLevel,
    connectorType,
    isFree,
    minPower,
    search,
    sortBy = 'createdAt',
    sortOrder = 'desc',
  } = req.query;

  const filter = { isActive: true };

  if (chargerLevel) {
    filter.chargerLevel = chargerLevel;
  }

  if (connectorType) {
    filter['connectors.type'] = connectorType;
  }

  if (isFree === 'true') {
    filter['pricing.isFree'] = true;
  }

  if (minPower) {
    filter['connectors.powerKW'] = { $gte: Number(minPower) };
  }

  if (search) {
    filter.$text = { $search: search };
  }

  const skip = (Number(page) - 1) * Number(limit);
  const sort = { [sortBy]: sortOrder === 'asc' ? 1 : -1 };

  const [stations, total] = await Promise.all([
    ChargingStation.find(filter)
      .sort(sort)
      .skip(skip)
      .limit(Number(limit))
      .lean(),
    ChargingStation.countDocuments(filter),
  ]);

  res.status(200).json({
    success: true,
    data: stations,
    pagination: {
      page: Number(page),
      limit: Number(limit),
      total,
      pages: Math.ceil(total / Number(limit)),
    },
  });
});

/**
 * @desc    Get nearby charging stations
 * @route   GET /api/stations/nearby?lat=X&lng=Y&radius=Z
 * @access  Public
 */
const getNearbyStations = asyncHandler(async (req, res) => {
  const { lat, lng, radius = 50, connectorType, chargerLevel } = req.query;

  if (!lat || !lng) {
    throw ApiError.badRequest('Latitude and longitude are required');
  }

  const radiusInMeters = Number(radius) * 1000;

  const matchStage = {
    'location.coordinates': {
      $near: {
        $geometry: {
          type: 'Point',
          coordinates: [Number(lng), Number(lat)],
        },
        $maxDistance: radiusInMeters,
      },
    },
    isActive: true,
  };

  if (connectorType) {
    matchStage['connectors.type'] = connectorType;
  }

  if (chargerLevel) {
    matchStage.chargerLevel = chargerLevel;
  }

  const stations = await ChargingStation.find(matchStage).limit(50).lean();

  // Add distance to each station
  const stationsWithDistance = stations.map((station) => {
    const [stationLng, stationLat] = station.location.coordinates;
    const distance = calculateHaversine(
      Number(lat),
      Number(lng),
      stationLat,
      stationLng
    );
    return { ...station, distance };
  });

  stationsWithDistance.sort((a, b) => a.distance - b.distance);

  res.status(200).json({
    success: true,
    data: stationsWithDistance,
    count: stationsWithDistance.length,
  });
});

/**
 * @desc    Get reachable stations based on battery range
 * @route   GET /api/stations/reachable?lat=X&lng=Y&battery=Z&range=W
 * @access  Public
 */
const getReachableStations = asyncHandler(async (req, res) => {
  const { lat, lng, battery, range } = req.query;

  if (!lat || !lng || !battery || !range) {
    throw ApiError.badRequest(
      'Latitude, longitude, battery percentage, and vehicle range are required'
    );
  }

  const { reachableDistance, safeDistance } = calculateReachableDistance(
    Number(battery),
    Number(range)
  );

  // Fetch stations within reachable distance
  const radiusInMeters = reachableDistance * 1000;
  const stations = await ChargingStation.find({
    'location.coordinates': {
      $near: {
        $geometry: {
          type: 'Point',
          coordinates: [Number(lng), Number(lat)],
        },
        $maxDistance: radiusInMeters,
      },
    },
    isActive: true,
  }).lean();

  const reachableStations = filterReachableStations(
    stations,
    Number(lat),
    Number(lng),
    safeDistance
  );

  res.status(200).json({
    success: true,
    data: {
      reachableDistance,
      safeDistance,
      stations: reachableStations,
      count: reachableStations.length,
      message: `You can safely reach ${reachableStations.length} charging station(s)`,
    },
  });
});

/**
 * @desc    Get a single station by ID
 * @route   GET /api/stations/:id
 * @access  Public
 */
const getStation = asyncHandler(async (req, res) => {
  const station = await ChargingStation.findById(req.params.id);

  if (!station) {
    throw ApiError.notFound('Charging station not found');
  }

  res.status(200).json({
    success: true,
    data: station,
  });
});

/**
 * @desc    Create a new charging station
 * @route   POST /api/stations
 * @access  Private/Admin
 */
const createStation = asyncHandler(async (req, res) => {
  req.body.addedBy = req.user.id;

  const station = await ChargingStation.create(req.body);

  logger.info(`New station created: ${station.name} by user ${req.user.id}`);

  res.status(201).json({
    success: true,
    data: station,
  });
});

/**
 * @desc    Update a charging station
 * @route   PUT /api/stations/:id
 * @access  Private/Admin
 */
const updateStation = asyncHandler(async (req, res) => {
  let station = await ChargingStation.findById(req.params.id);

  if (!station) {
    throw ApiError.notFound('Charging station not found');
  }

  station = await ChargingStation.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true,
  });

  logger.info(`Station updated: ${station.name} by user ${req.user.id}`);

  res.status(200).json({
    success: true,
    data: station,
  });
});

/**
 * @desc    Delete a charging station (soft delete)
 * @route   DELETE /api/stations/:id
 * @access  Private/Admin
 */
const deleteStation = asyncHandler(async (req, res) => {
  const station = await ChargingStation.findById(req.params.id);

  if (!station) {
    throw ApiError.notFound('Charging station not found');
  }

  station.isActive = false;
  await station.save();

  logger.info(`Station soft-deleted: ${station.name} by user ${req.user.id}`);

  res.status(200).json({
    success: true,
    message: 'Station deleted successfully',
  });
});

/**
 * @desc    Get station analytics (Admin)
 * @route   GET /api/stations/analytics/overview
 * @access  Private/Admin
 */
const getStationAnalytics = asyncHandler(async (req, res) => {
  const [totalStations, stationsByLevel, stationsByConnector, recentStations] =
    await Promise.all([
      ChargingStation.countDocuments({ isActive: true }),
      ChargingStation.aggregate([
        { $match: { isActive: true } },
        { $group: { _id: '$chargerLevel', count: { $sum: 1 } } },
      ]),
      ChargingStation.aggregate([
        { $match: { isActive: true } },
        { $unwind: '$connectors' },
        { $group: { _id: '$connectors.type', count: { $sum: 1 } } },
      ]),
      ChargingStation.find({ isActive: true })
        .sort({ createdAt: -1 })
        .limit(5)
        .select('name location.address.city chargerLevel createdAt')
        .lean(),
    ]);

  res.status(200).json({
    success: true,
    data: {
      totalStations,
      stationsByLevel,
      stationsByConnector,
      recentStations,
    },
  });
});

/**
 * Helper: Haversine formula for distance calculation
 */
function calculateHaversine(lat1, lon1, lat2, lon2) {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

module.exports = {
  getStations,
  getNearbyStations,
  getReachableStations,
  getStation,
  createStation,
  updateStation,
  deleteStation,
  getStationAnalytics,
};
