const express = require('express');
const router = express.Router();
const {
  calculateCharge,
  quickEstimate,
} = require('../controllers/calculatorController');
const { calculationValidation, validate } = require('../middleware/validation');

router.post('/charge', calculationValidation, validate, calculateCharge);
router.post('/quick-estimate', quickEstimate);

module.exports = router;
