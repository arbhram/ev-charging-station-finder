const express = require('express');
const router = express.Router();
const {
  getStations,
  getNearbyStations,
  getReachableStations,
  getStation,
  createStation,
  updateStation,
  deleteStation,
  getStationAnalytics,
} = require('../controllers/stationController');
const { protect, authorize } = require('../middleware/auth');
const {
  stationValidation,
  objectIdValidation,
  validate,
} = require('../middleware/validation');

// Public routes
router.get('/', getStations);
router.get('/nearby', getNearbyStations);
router.get('/reachable', getReachableStations);

// Admin routes
router.get('/analytics/overview', protect, authorize('admin'), getStationAnalytics);

// Parameterized routes
router.get('/:id', objectIdValidation(), validate, getStation);
router.post('/', protect, authorize('admin'), stationValidation, validate, createStation);
router.put('/:id', protect, authorize('admin'), objectIdValidation(), validate, updateStation);
router.delete('/:id', protect, authorize('admin'), objectIdValidation(), validate, deleteStation);

module.exports = router;
